//
//  BaseVC.swift
//  SwiftyMovies
//
//  Created by Hamza Farooq on 02/06/2021.
//

import UIKit
import Photos
import Kingfisher

class BaseVC: UIViewController {
    
    var refreshControlFunction: (()->())?
    @objc var refreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.isHidden = true
        
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    func setUpNavBarAppearance() {
    
        let navigationBarAppearace = UINavigationBar.appearance()
        
        navigationBarAppearace.isTranslucent = false
        // change navigation bar icons color
        navigationBarAppearace.tintColor = .color_white
        // change navigation item title color
        navigationBarAppearace.titleTextAttributes = [
            NSAttributedString.Key.foregroundColor: UIColor.color_white,
//            NSAttributedString.Key.font: UIFont(name: SharedManager.heavyFont(), size: 18)!
        ]
        // to hide navbar bottom border
        navigationBarAppearace.shadowImage = UIImage()
        // to change the background color of navbar
        navigationBarAppearace.barTintColor = .color_gray_6
        
    }
    
    func downLoadImageIntoImageView(url: String, imageView: UIImageView, placeholder: UIImage?) {
        
        if url == "" {
            imageView.image = placeholder
            return
        }
        
        let completeString = url
        let finalUrl = completeString.addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlQueryAllowed)!
        
        //  keepCurrentImageWhileLoading
        //  fromMemoryCacheOrRefresh
        
        let downloadUrl = URL(string: finalUrl)
        
        imageView.kf.indicatorType = .activity
        
        var options: KingfisherOptionsInfo = []
        
        options.append(.transition(.fade(1)))
        options.append(.loadDiskFileSynchronously)
        
        imageView.kf.setImage(with: downloadUrl, placeholder: placeholder, options: options, progressBlock: nil) { (result) in
            
        }
        
    }
    
    func addRefreshControl(isCollectionView: Bool, collectionView: UICollectionView?, tableView: UITableView?, titleOfRefresh: String, refrence: UIViewController , action: @escaping ()->()) -> Void {
        
        self.refreshControlFunction = action
        
        let title = NSLocalizedString(titleOfRefresh, comment: "")
        
        refreshControl.attributedTitle = NSAttributedString(string: title)
        refreshControl.tintColor = .color_white
        
        refreshControl.addTarget(refrence, action: #selector(refresh), for: .valueChanged)
        
        if isCollectionView {
            collectionView?.refreshControl = refreshControl
        } else {
            tableView?.refreshControl = refreshControl
        }
        
    }
    
    @objc func refresh() {
        refreshControlFunction?()
    }
    
    func endRefreshing() {
        refreshControl.endRefreshing()
    }
    
    func makeHomeScreenRootVC() {
            
        guard let window = UIApplication.getKeyWindow() else { return }
            
        let vc = self.getMainStoryBoard().instantiateViewController(withIdentifier: VCIdentifiers.HomeViewController)
        
        UIView.transition(with: window, duration: 0.5, options: .transitionFlipFromRight, animations: {
            
            window.rootViewController = vc
            
        }, completion: nil)
        
    }
    
}

extension BaseVC {
    
    func getMainStoryBoard() -> UIStoryboard {
    
        return UIStoryboard.init(name: ConstantsStruct.MAIN, bundle: nil)
        
    }
    
}

extension BaseVC {
    
    func setUpBackBarButton() -> UIBarButtonItem {
        
        self.navigationController?.navigationBar.isHidden = false
        
        let backItem = UIBarButtonItem(image: #imageLiteral(resourceName: "back"), style: .plain, target: self, action: #selector(goBack))
        
        return backItem
        
    }
    
    @objc func goBack() {
        
        self.navigationController?.popViewController(animated: true)
        
    }
    
}

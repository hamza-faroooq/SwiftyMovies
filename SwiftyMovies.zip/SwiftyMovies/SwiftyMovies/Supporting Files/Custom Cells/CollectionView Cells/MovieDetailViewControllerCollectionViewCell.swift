//
//  MovieDetailViewControllerCollectionViewCell.swift
//  SwiftyMovies
//
//  Created by Hamza Farooq on 04/06/2021.
//

import UIKit

class MovieDetailViewControllerCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var movieImageView: UIImageView!
    
}

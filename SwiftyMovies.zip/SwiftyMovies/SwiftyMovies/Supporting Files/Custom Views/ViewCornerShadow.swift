//
//  ViewCornerShadow.swift
//
//  Created by Hamza on 19/02/2020.
//

import UIKit

class ViewCornerShadow: UIView {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.layer.cornerRadius = 8
        self.layer.shadowRadius = 3
        self.layer.shadowOpacity = 0.5
        self.layer.shadowColor = UIColor.color_gray_3.cgColor
        self.layer.shadowOffset = CGSize(width: 3, height: 3)
        
    }
    
}

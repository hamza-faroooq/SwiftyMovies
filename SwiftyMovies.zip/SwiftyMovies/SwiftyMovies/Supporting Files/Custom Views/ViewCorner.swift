//
//  ViewCorner.swift
//
//  Created by Hamza on 19/02/2020.
//

import UIKit

class ViewCorner: UIView {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.layer.cornerRadius = 8
        self.clipsToBounds = true
        
    }
    
}

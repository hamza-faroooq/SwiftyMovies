//
//  ViewShadow.swift
//
//  Created by Hamza on 19/02/2020.
//

import UIKit

class ViewShadow: UIView {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.layer.masksToBounds = false
        
        self.layer.shadowRadius = 2
        self.layer.shadowOpacity = 0.6
        self.layer.shadowColor = UIColor.color_gray_5.cgColor
        self.layer.shadowOffset = CGSize.init(width: 0, height: 0)
        
    }
    
}

//
//  Extentions.swift
//
//  Created by Hamza on 19/02/2020.
//

import UIKit

extension UIImageView {
    
    func setImageColor(color: UIColor) {
        
        let templateImage = self.image?.withRenderingMode(.alwaysTemplate)
        self.image = templateImage
        self.tintColor = color
        
    }
    
}

extension UIButton {
    
    func setImageColor(color: UIColor) {
        
        let templateImage = self.currentImage?.withRenderingMode(.alwaysTemplate)
        self.setImage(templateImage, for: .normal)
        self.tintColor = color
        
    }
    
}

extension String {
    
    var htmlToString: String {
        return htmlToAttributedString?.string ?? ""
    }
    
    var htmlToAttributedString: NSAttributedString? {

        guard let data = data(using: .utf8) else { return NSAttributedString() }
        
        do {
            
            return try NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding: String.Encoding.utf8.rawValue], documentAttributes: nil)
            
        } catch {
            return NSAttributedString()
        }
        
    }
    
}

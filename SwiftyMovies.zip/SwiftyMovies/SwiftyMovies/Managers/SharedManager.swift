//
//  SharedManager.swift
//  Key Car Sharing
//
//  Created by Hamza on 28/01/2021.
//  Copyright © 2020 Hamza. All rights reserved.
//

import UIKit

class SharedManager: NSObject  {
    
    static let sharedInstance = SharedManager()
    
    var ScreenWidth = UIScreen.main.bounds.width
    var ScreenHeight = UIScreen.main.bounds.height

    var isGridView: Bool = false
    
}

//
//  ViewRound.swift
//
//  Created by Hamza on 19/02/2020.
//

import UIKit

class ViewRound: UIView {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.layer.cornerRadius = self.frame.size.height / 2
        self.clipsToBounds = true
        
    }
    
}

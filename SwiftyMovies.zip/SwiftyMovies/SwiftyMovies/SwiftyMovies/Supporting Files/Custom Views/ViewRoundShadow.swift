//
//  ViewRoundShadow.swift
//
//  Created by Hamza on 19/02/2020.
//

import UIKit

class ViewRoundShadow: UIView {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.layer.cornerRadius = self.frame.size.height / 2
        
        self.layer.shadowRadius = 2
        self.layer.shadowOpacity = 0.5
        self.layer.shadowColor = UIColor.color_gray_5.cgColor
        self.layer.shadowOffset = CGSize(width: 0, height: 2)
        
    }
    
}

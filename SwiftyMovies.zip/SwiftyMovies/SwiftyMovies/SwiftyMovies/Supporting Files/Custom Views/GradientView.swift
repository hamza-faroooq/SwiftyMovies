//
//  GradientView.swift
//
//  Created by Hamza on 19/02/2020.
//

import UIKit

class GradientView: UIView {
    
    var gradientLayer: CAGradientLayer!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        if gradientLayer != nil {
            gradientLayer.frame = self.bounds
        }
        
    }
    
    func applyGradient(colours: [UIColor]) -> Void {
        
        if gradientLayer == nil {
            
            gradientLayer = CAGradientLayer()
            
            gradientLayer.colors = colours.map { $0.cgColor }
            
//            from left to right gradient effect
            gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
            gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
            
////            from bottom-left to top-right - diagonal effect
//            gradientLayer.startPoint = CGPoint(x: 0, y: 1)
//            gradientLayer.endPoint = CGPoint(x: 1, y: 0)
            
//            from top to bottom effect
//            gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
//            gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0)
            
            self.layer.insertSublayer(gradientLayer, at: 0)
            
        }
        
    }
    
}

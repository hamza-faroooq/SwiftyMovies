//
//  ViewCornerBorder.swift
//
//  Created by Hamza on 19/02/2020.
//

import UIKit

class ViewCornerBorder: UIView {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.layer.cornerRadius = 8
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor.color_gray_2.cgColor
        self.clipsToBounds = true
        
    }
    
}

//
//  Extensions+Colors.swift
//
//  Created by Hamza on 12/08/2020.
//

import UIKit

extension UIColor {
    
    static let color_red = UIColor.red
    static let color_cyan = UIColor.cyan
    static let color_clear = UIColor.clear
    static let color_black = UIColor.black
    static let color_white = UIColor.white
    static let color_green = UIColor.green
    static let color_orange = UIColor.orange
    static let color_yellow = UIColor.yellow
    
    static let color_greenish = #colorLiteral(red: 0.3882352941, green: 0.7921568627, blue: 0.1490196078, alpha: 1)
    static let color_redish = #colorLiteral(red: 0.9725490196, green: 0.3607843137, blue: 0.3607843137, alpha: 1)
    static let color_purple = #colorLiteral(red: 0.6039215686, green: 0.0862745098, blue: 0.7843137255, alpha: 1)
    
    static let color_gray_1 = #colorLiteral(red: 0.9294117647, green: 0.9294117647, blue: 0.9294117647, alpha: 1)
    static let color_gray_2 = #colorLiteral(red: 0.8705882353, green: 0.8705882353, blue: 0.8705882353, alpha: 1)
    static let color_gray_3 = #colorLiteral(red: 0.8, green: 0.8, blue: 0.8, alpha: 1)
    static let color_gray_4 = #colorLiteral(red: 0.5333333333, green: 0.5333333333, blue: 0.5333333333, alpha: 1)
    static let color_gray_5 = #colorLiteral(red: 0.4, green: 0.4, blue: 0.4, alpha: 1)
    static let color_gray_6 = #colorLiteral(red: 0.2666666667, green: 0.2666666667, blue: 0.2666666667, alpha: 1)
    static let color_gray_7 = #colorLiteral(red: 0.1333333333, green: 0.1333333333, blue: 0.1333333333, alpha: 1)
    
    static let color_orange_1 = #colorLiteral(red: 1, green: 0.7254901961, blue: 0.4, alpha: 1)
    static let color_orange_2 = #colorLiteral(red: 1, green: 0.6823529412, blue: 0.3019607843, alpha: 1)
    static let color_orange_3 = #colorLiteral(red: 1, green: 0.6352941176, blue: 0.2, alpha: 1)
    static let color_orange_4 = #colorLiteral(red: 1, green: 0.5882352941, blue: 0.1019607843, alpha: 1)
    
    static let color_light_greenish_yellow = #colorLiteral(red: 0.9411764706, green: 0.9411764706, blue: 0.8862745098, alpha: 1)
    static let color_dark_greenish_yellow = #colorLiteral(red: 0.8235294118, green: 0.8235294118, blue: 0.7254901961, alpha: 1)
    
    static let color_navBar = #colorLiteral(red: 0.9803921569, green: 0.9803921569, blue: 0.9803921569, alpha: 1)
    
    static func hexStringToUIColor (hex: String) -> UIColor {
        
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()

        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }

        if ((cString.count) != 6) {
            return UIColor.gray
        }

        var rgbValue:UInt64 = 0
        
        Scanner(string: cString).scanHexInt64(&rgbValue)

        return UIColor(
            
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
            
        )
        
    }
    
}

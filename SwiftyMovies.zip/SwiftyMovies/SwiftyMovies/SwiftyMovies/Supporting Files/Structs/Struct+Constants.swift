//
//  Struct+Constants.swift
//  SwiftyMovies
//
//  Created by Hamza Farooq on 02/06/2021.
//

struct ConstantsStruct {
    
    // Storyboard Names
    static let MAIN = "Main"
    
    // Alert Constants
    static let OKAY = "Okay"
    static let ALERT = "Alert"
    static let CHOOSE_OPTIONS = "Choose from the options"
    static let CANCEL = "Cancel"
    static let REFRESHING = "Pull to refresh"
    static let COMING_SOON_MESSAGE = "COMING SOON!"
    static let ERROR_MESSAGE = "WE ARE SORRY NO DATA FOUND"
    static let SOMETHING_WENT_WRONG_MESSAGE = "Something went wrong, try again later!"
    static let TEXT_COPIED = "Text Copied"
    static let INTERNET_ERROR = "Make sure your device is connected to the internet"
    
}

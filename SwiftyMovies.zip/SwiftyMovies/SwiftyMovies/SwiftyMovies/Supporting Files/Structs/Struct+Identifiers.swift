//
//  Struct+Identifiers.swift
//  SwiftyMovies
//
//  Created by Hamza Farooq on 02/06/2021.
//

struct VCIdentifiers {
    
    static let HomeViewController = "HomeViewController"
    static let MovieDetailViewController = "MovieDetailViewController"
    
}
    
struct CellIdentifiers {
    
    static let LIST_CELL = "listCell"
    static let GRID_CELL = "gridCell"
    
    static let CELL = "cell"
    
}

//
//  ViewController.swift
//  SwiftyMovies
//
//  Created by Hamza Farooq on 02/06/2021.
//

import UIKit

class HomeViewController: BaseVC {

    @IBOutlet weak var collectionView: UICollectionView!
    
    var limit: Int = 0
    var movie_count: Int = 0
    var page_number: Int = 0
    
    var moviesArray = [MovieObject]()
    var filteredArray = [MovieObject]()
    
    override func viewDidLoad() {
        
        self.setUpInitials()
     
        self.getMoviesList()
        
    }

    func setUpInitials() {
        
        let searchBar = UISearchBar()
        searchBar.searchTextField.textColor = .color_white
        
        self.navigationItem.titleView = searchBar
        
        self.navigationItem.rightBarButtonItem = self.setUpGridBarButton()
        
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        
        searchBar.delegate = self
        
        addRefreshControl(isCollectionView: true, collectionView: self.collectionView, tableView: nil, titleOfRefresh: "", refrence: self) {
            
            self.getMoviesList()
            
        }
        
    }
    
}

extension HomeViewController {
    
    func getMoviesList() {
        
        ApiManager.alamofireRequest(ApiEndpoint: API_EndPoints.get_movies_list, method: .get, parameters: [:], isShowAI: true, mainView: self.view) { response, message in
            
            if let data = response["data"] as? NSDictionary {
                
                self.limit = data["limit"] as? Int ?? 0
                self.movie_count = data["movie_count"] as? Int ?? 0
                self.page_number = data["page_number"] as? Int ?? 0
                
                if let movies = data["movies"] as? NSArray {
                    
                    self.moviesArray.removeAll()
                    self.filteredArray.removeAll()
                    
                    movies.forEach { item in
                        
                        if let singleItem = item as? NSDictionary {
                            
                            let parseItem = MovieObject.parseMoviesData(dict: singleItem)
                            self.moviesArray.append(parseItem)
                            
                        }
                        
                    }
                    
                }
                
            }
            
            self.filteredArray = self.moviesArray
            
            self.collectionView.reloadData()
            self.endRefreshing()
            
        } errorCallBack: { error in
            
            AlertManager.customAlertView(messageString: error)
            self.endRefreshing()
            
        }

        
    }
    
}

extension HomeViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.filteredArray.count
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        var identifier = CellIdentifiers.LIST_CELL
        
        if SharedManager.sharedInstance.isGridView {
            identifier = CellIdentifiers.GRID_CELL
        }
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: identifier, for: indexPath) as! HomeCollectionViewCell
        
        let singleItem = self.filteredArray[indexPath.item]
        
        downLoadImageIntoImageView(url: singleItem.large_cover_image, imageView: cell.movieImageView, placeholder: nil)
        
        cell.movieTitleLabel.text = singleItem.title
        cell.movieYearLabel.text = "\(singleItem.year)"
        
        if !SharedManager.sharedInstance.isGridView {
            
            downLoadImageIntoImageView(url: singleItem.background_image, imageView: cell.movieBackgroundImageView, placeholder: nil)
            cell.movieLanguageLabel.text = "[Language: \(singleItem.language)]"
            
            cell.movieGenresLabel.text = singleItem.genres.joined(separator: " / ")
            
            cell.availableInLabel.text = "Available In: "
            
            singleItem.torrents.forEach { item in
                cell.availableInLabel.text?.append(item.quality + "." + item.type + " ")
            }
            
            cell.ratingLabel.text = singleItem.rating
            cell.starImageView.setImageColor(color: .color_greenish)
            
        }
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if SharedManager.sharedInstance.isGridView {
            return CGSize(width: SharedManager.sharedInstance.ScreenWidth / 2, height: 250)
        } else {
            return CGSize(width: SharedManager.sharedInstance.ScreenWidth, height: 180)
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let vc = getMainStoryBoard().instantiateViewController(withIdentifier: VCIdentifiers.MovieDetailViewController) as! MovieDetailViewController
        
        vc.movie_id = self.filteredArray[indexPath.item].id
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
}

extension HomeViewController {
    
    func setUpGridBarButton() -> UIBarButtonItem {
        
        self.navigationController?.navigationBar.isHidden = false
        
        var item = UIBarButtonItem(image: #imageLiteral(resourceName: "icons8-list-50"), style: .plain, target: self, action: #selector(changeView))
        
        if !SharedManager.sharedInstance.isGridView {
            
            item = UIBarButtonItem(image: #imageLiteral(resourceName: "icons8-grid-50"), style: .plain, target: self, action: #selector(changeView))
            
        }
        
        return item
        
    }
    
    @objc func changeView() {
        
        SharedManager.sharedInstance.isGridView.toggle()
        self.navigationItem.rightBarButtonItem = setUpGridBarButton()
        self.collectionView.reloadData()
        
    }
    
}

extension HomeViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if searchText.isEmpty {
            
            self.filteredArray = self.moviesArray
            
        } else {
            
            self.filteredArray = self.moviesArray.filter({
                $0.title.contains(searchText)
            })
            
        }
        
        self.collectionView.reloadData()
        
    }
    
}

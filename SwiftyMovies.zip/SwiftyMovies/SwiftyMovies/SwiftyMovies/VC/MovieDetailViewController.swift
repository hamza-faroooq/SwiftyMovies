//
//  MovieDetailViewController.swift
//  SwiftyMovies
//
//  Created by Hamza Farooq on 04/06/2021.
//

import UIKit

class MovieDetailViewController: BaseVC {

    @IBOutlet weak var outerView: UIView!
    @IBOutlet weak var backgroundImageView: UIImageView!
    @IBOutlet weak var movieImageView: UIImageView!
    @IBOutlet weak var yearLabel: UILabel!
    @IBOutlet weak var genreLabel: UILabel!
    @IBOutlet weak var availableInLabel: UILabel!
    @IBOutlet weak var likeCountLabel: UILabel!
    @IBOutlet weak var heartIconImage: UIImageView!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var starIconImage: UIImageView!
    @IBOutlet weak var downloadButtonOuterView: UIView!
    @IBOutlet weak var synopsisValueLabel: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var movie_id: Int = 0
    var movieObj = MovieObject()
    var movieSuggessionArray = [MovieObject]()
    
    override func viewDidLoad() {
        
        self.outerView.isHidden = true
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        self.getMovieDetail()
        
    }
    
    func setUpData() {
        
        self.outerView.isHidden = false
        
        self.navigationItem.title = self.movieObj.title
        
        downLoadImageIntoImageView(url: self.movieObj.background_image, imageView: self.backgroundImageView, placeholder: nil)
        downLoadImageIntoImageView(url: self.movieObj.large_cover_image, imageView: self.movieImageView, placeholder: nil)
        
        self.yearLabel.text = "\(self.movieObj.year)"
        self.genreLabel.text = self.movieObj.genres.joined(separator: " / ")
        
        self.availableInLabel.text = "Available In: "
        
        self.movieObj.torrents.forEach { item in
            self.availableInLabel.text?.append(item.quality + "." + item.type + " ")
        }
        
        self.heartIconImage.setImageColor(color: .color_greenish)
        self.likeCountLabel.text = "\(self.movieObj.like_count)"
        
        self.ratingLabel.text = self.movieObj.rating
        self.starIconImage.setImageColor(color: .color_greenish)
        
        self.downloadButtonOuterView.backgroundColor = .color_greenish
        
        self.synopsisValueLabel.text = self.movieObj.description_full
        
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        
    }
    
    @IBAction func downloadButtonAction(_ sender: UIButton) {
        
        if let urlString = self.movieObj.torrents.first?.url {
            
            let url = URL(string: urlString)!
            
            if UIApplication.shared.canOpenURL(url) {
                
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
                
            }
            
        } else {
            
            AlertManager.customAlertView(messageString: "Download link not available")
            
        }
        
    }
    
}

extension MovieDetailViewController {
    
    func getMovieDetail() {
        
        let param = ["movie_id": self.movie_id]
        
        ApiManager.alamofireRequest(ApiEndpoint: API_EndPoints.get_movie_details, method: .get, parameters: param, isShowAI: true, mainView: self.view) { response, message in
            
            if let data = response["data"] as? NSDictionary {
                
                if let movie = data["movie"] as? NSDictionary {
                    
                    let parseItem = MovieObject.parseMoviesData(dict: movie)
                            
                    self.movieObj = parseItem
                
                    self.getMovieSuggessions()
                    
                }
            
            }
            
        } errorCallBack: { error in
            
            AlertManager.customAlertView(messageString: error)
            self.endRefreshing()
            
        }
        
    }
    
    func getMovieSuggessions() {
        
        let param = ["movie_id": self.movie_id]
        
        ApiManager.alamofireRequest(ApiEndpoint: API_EndPoints.get_movie_suggestions, method: .get, parameters: param, isShowAI: true, mainView: self.view) { response, message in
            
            if let data = response["data"] as? NSDictionary {
                
                if let movies = data["movies"] as? NSArray {

                    for item in movies {
                        
                        if let singleItem = item as? NSDictionary {
                            
                            let parseItem = MovieObject.parseMoviesData(dict: singleItem)
                            self.movieSuggessionArray.append(parseItem)
                            
                        }
                        
                    }

                }
            
                self.setUpData()
                
            }
            
        } errorCallBack: { error in
            
            AlertManager.customAlertView(messageString: error)
            self.endRefreshing()
            
        }
        
    }
    
}

extension MovieDetailViewController: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        self.movieSuggessionArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifiers.CELL, for: indexPath) as! MovieDetailViewControllerCollectionViewCell
        
        downLoadImageIntoImageView(url: self.movieSuggessionArray[indexPath.item].medium_cover_image, imageView: cell.movieImageView, placeholder: nil)
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: SharedManager.sharedInstance.ScreenWidth / 2, height: 250)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let vc = getMainStoryBoard().instantiateViewController(withIdentifier: VCIdentifiers.MovieDetailViewController) as! MovieDetailViewController
        
        vc.movie_id = self.movieSuggessionArray[indexPath.item].id
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
}

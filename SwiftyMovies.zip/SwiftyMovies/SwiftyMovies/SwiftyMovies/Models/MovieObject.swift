//
//  MovieObject.swift
//  SwiftyMovies
//
//  Created by Hamza Farooq on 02/06/2021.
//

import UIKit

class MovieObject: NSObject {

    var background_image: String = ""
    var background_image_original: String = ""
    var date_uploaded: String = ""
    var date_uploaded_unix: Int = 0
    var description_full: String = ""
    var description_intro: String = ""
    var id: Int = 0
    var imdb_code: String = ""
    var language: String = ""
    var large_cover_image: String = ""
    var medium_cover_image: String = ""
    var mpa_rating: String = ""
    var rating: String = ""
    var runtime: Int = 0
    var slug: String = ""
    var small_cover_image: String = ""
    var summary: String = ""
    var synopsis: String = ""
    var title: String = ""
    var title_english: String = ""
    var title_long: String = ""
    var url: String = ""
    var year: Int = 0
    var yt_trailer_code: String = ""
    
    var genres: [String] = [String]()
    
    var torrents = [torrentObject]()
    
    var download_count: Int = 0
    var like_count: Int = 0
    
    class func parseMoviesData(dict: NSDictionary) -> MovieObject {
        
        let obj = MovieObject()
        
        obj.background_image = dict["background_image"] as? String ?? ""
        obj.background_image_original = dict["background_image_original"] as? String ?? ""
        obj.date_uploaded = dict["date_uploaded"] as? String ?? ""
        obj.date_uploaded_unix = dict["date_uploaded_unix"] as? Int ?? 0
        obj.description_full = dict["description_full"] as? String ?? ""
        obj.description_intro = dict["description_intro"] as? String ?? ""
        obj.id = dict["id"] as? Int ?? 0
        obj.imdb_code = dict["imdb_code"] as? String ?? ""
        obj.language = dict["language"] as? String ?? ""
        obj.large_cover_image = dict["large_cover_image"] as? String ?? ""
        obj.medium_cover_image = dict["medium_cover_image"] as? String ?? ""
        obj.mpa_rating = dict["mpa_rating"] as? String ?? ""
        
        let rating = dict["rating"] as? Double ?? 0.0
        obj.rating = String(format: "%.1f", rating)
        
        
        obj.runtime = dict["runtime"] as? Int ?? 0
        obj.slug = dict["slug"] as? String ?? ""
        obj.small_cover_image = dict["small_cover_image"] as? String ?? ""
        obj.summary = dict["summary"] as? String ?? ""
        obj.synopsis = dict["synopsis"] as? String ?? ""
        obj.title = dict["title"] as? String ?? ""
        obj.title_english = dict["title_english"] as? String ?? ""
        obj.title_long = dict["title_long"] as? String ?? ""
        obj.url = dict["url"] as? String ?? ""
        obj.year = dict["year"] as? Int ?? 0
        obj.yt_trailer_code = dict["yt_trailer_code"] as? String ?? ""
        
        if let genres = dict["genres"] as? NSArray {
            
            genres.forEach { item in
                obj.genres.append(item as? String ?? "")
            }
            
        }
        
        if let torrents = dict["torrents"] as? NSArray {
            
            torrents.forEach { item in
                
                if let itemDict = item as? NSDictionary {
                    
                    let parsedItem = torrentObject.parseMoviesData(dict: itemDict)
                    obj.torrents.append(parsedItem)
                    
                }
                
            }
            
        }
        
        obj.download_count = dict["download_count"] as? Int ?? 0
        obj.like_count = dict["like_count"] as? Int ?? 0
        
        return obj
        
    }
    
}

class torrentObject: NSObject {
    
    var date_uploaded: String = ""
    var date_uploaded_unix: Int = 0
    var _hash: String = ""
    var peers: Int = 0
    var quality: String = ""
    var seeds: Int = 0
    var size: String = ""
    var size_bytes: Int = 0
    var type: String = ""
    var url: String = ""
    
    class func parseMoviesData(dict: NSDictionary) -> torrentObject {
        
        let obj = torrentObject()
        
        obj.date_uploaded = dict["date_uploaded"] as? String ?? ""
        obj.date_uploaded_unix = dict["date_uploaded_unix"] as? Int ?? 0
        obj._hash = dict["hash"] as? String ?? ""
        obj.peers = dict["peers"] as? Int ?? 0
        obj.quality = dict["quality"] as? String ?? ""
        obj.seeds = dict["seeds"] as? Int ?? 0
        obj.size = dict["size"] as? String ?? ""
        obj.size_bytes = dict["size_bytes"] as? Int ?? 0
        obj.type = dict["type"] as? String ?? ""
        obj.url = dict["url"] as? String ?? ""
        
        return obj
        
    }
    
}

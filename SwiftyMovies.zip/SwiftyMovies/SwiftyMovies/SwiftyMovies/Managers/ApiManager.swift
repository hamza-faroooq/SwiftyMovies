//
//  ApiManager.swift
//
//  Created by Hamza on 20/04/2021.
//

import UIKit
import Alamofire
import NVActivityIndicatorView

class ApiManager: NSObject {
    
    static let AIView = NVActivityIndicatorView.init(frame: CGRect(x: (SharedManager.sharedInstance.ScreenWidth / 2) - 25, y: (SharedManager.sharedInstance.ScreenHeight / 2) - 100, width: 50, height: 50), type: .circleStrokeSpin, color: .color_orange_4, padding: 0)
    
    class func alamofireRequest(ApiEndpoint: String, method: HTTPMethod, isAuthHeader: Bool = false, parameters: Parameters, isShowAI: Bool, mainView: UIView, successCallback: @escaping (NSDictionary, String) -> Void, errorCallBack: @escaping (String) -> Void) {
        
        if !Reachability.isConnectedToNetwork() {
            
            errorCallBack(ConstantsStruct.INTERNET_ERROR)
            return
            
        }
        
        let URLString = API_EndPoints.BASE_URL + ApiEndpoint
        let url = URLString.addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlQueryAllowed)!
        
        let header: HTTPHeaders = [:]
        
        print(url)
        print(header)
        print(parameters)
        
        startActivityIndicator(mainView: mainView)
        
        Alamofire.request(url, method: method, parameters: parameters, headers: header).responseJSON { response in
            
            print(response)
            
            stopActivityIndicator(mainView: mainView)
            
            var message = ConstantsStruct.SOMETHING_WENT_WRONG_MESSAGE
            
            if let JSON = response.result.value as? [String: Any] {
                
                print(JSON)
                
//                print(HTTPCookieStorage.shared.cookies!) // to access cookies in api response
                
                if let responseMessage = JSON["status_message"] as? String {
                    message = responseMessage
                }
                
                if let isStatus = JSON["status"] as? String {
                    
                    if isStatus == "ok" {
                        
                        let jsonData = (JSON as NSDictionary)
                        
                        successCallback(jsonData, message)
                        return
                        
                    }
                    
                }
                
                errorCallBack(message)
                
            } else {
                
                errorCallBack(message)
                
            }
            
        }
        
    }
    
    class func startActivityIndicator(mainView: UIView) {
        
        mainView.addSubview(ApiManager.AIView)
        ApiManager.AIView.startAnimating()
        UIApplication.shared.beginIgnoringInteractionEvents()
        
    }
    
    class func stopActivityIndicator(mainView: UIView) {
        
        UIApplication.shared.endIgnoringInteractionEvents()
        ApiManager.AIView.stopAnimating()
        mainView.willRemoveSubview(ApiManager.AIView)
        
    }
    
    class func getAppVersion() -> String {
        
        let version = Bundle.main.infoDictionary!["CFBundleShortVersionString"]!
        return version as! String
        
    }
    
}

struct API_EndPoints {
    
    static let BASE_URL = "https://yts.mx/api/v2/"
    
    static let get_movies_list = "list_movies.json"
    static let get_movie_details = "movie_details.json" // got the details from Husnain via LinkedIn
    static let get_movie_comments = "movie_comments.json" // API is not working, asked via EMAIL but no response
    static let get_movie_suggestions = "movie_suggestions.json"// got the details from Husnain via LinkedIn
    
}
